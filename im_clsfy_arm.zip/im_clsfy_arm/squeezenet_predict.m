%Copyright 2020 - 2020 The MathWorks, Inc.

function outImg = squeezenet_predict(I)
%#codegen

persistent net;
opencv_linkflags = '`pkg-config --cflags --libs opencv`';
coder.updateBuildInfo('addLinkFlags',opencv_linkflags);

if isempty(net)
    net = coder.loadDeepLearningNetwork('squeezenet', 'squeezenet');
 end

in=zeros(227,227,3);
in(:,:,:) = imresize(I,[227,227]);
predict_scores = net.predict(in);

% Annotate detections in the image.
outImg = postprocess(in,predict_scores);