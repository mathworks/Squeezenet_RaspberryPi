%Copyright 2020 - 2020 The MathWorks, Inc.

I=imread('peppers.png');
out = squeezenet_predict(I);
imshow(out);

%% Connect to the Raspberry Pi Hardware

hwobj = raspi('ipaddress','login','password'); 
w = hwobj.webcam;

%% Test with live data

for i=1:1000
img=snapshot(w);
outimg = squeezenet_predict(img);
imshow(outimg);
end


%% Generate C++ Code for the Target Using MATLAB Coder

fcnName='squeezenet_predict';
cfg = coder.config('lib');
cfg.TargetLang = 'C++';

dlcfg = coder.DeepLearningConfig('arm-compute');
dlcfg.ArmArchitecture = 'armv7';
dlcfg.ArmComputeVersion = '18.03';

cfg.DeepLearningConfig = dlcfg;

hw=coder.hardware('Raspberry Pi');
cfg.Hardware=hw;
cfg.Hardware.BuildDir = '~/im_classify';
cfg.VerificationMode = 'PIL';
 
%cfg.CustomInclude = fullfile('codegen','exe',fcnName,'example');
%cfg.CustomSource  = fullfile('main.cpp');

%% 
codegen -config cfg squeezenet_predict -args {coder.typeof(uint8(ones(227,227,3)) ,[1024,1024,3],[1,1,0])} -report

%% Run in PIL mode

for i=1:100
%I=imread('peppers.png');
%outimg = squeezenet_predict_pil(I);
img=snapshot(w);
outimg = squeezenet_predict_pil(img);
imshow(outimg);
end


%% Stand alone deployment

fcnName='squeezenet_predict';
cfg = coder.config('lib');
cfg.TargetLang = 'C++';

dlcfg = coder.DeepLearningConfig('arm-compute');
dlcfg.ArmArchitecture = 'armv7';
dlcfg.ArmComputeVersion = '18.03';

cfg.DeepLearningConfig = dlcfg;

hw=coder.hardware('Raspberry Pi');
cfg.Hardware=hw;
cfg.Hardware.BuildDir = '~/im_classify';

cfg.CustomInclude = fullfile('codegen','exe',fcnName,'example');
cfg.CustomSource  = fullfile('main.cpp');


%% Run the Executable on the Target
   exe = 'im_classify.elf';

% Use the |runExecutable()| method of the hardware object to launch the
% exectuable on the target hardware.

hwobj.runExecutable(exe,'CamVid.avi');


