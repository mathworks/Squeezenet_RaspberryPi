%Copyright 2020 - 2020 The MathWorks, Inc.

function outImg = postprocess(im,predict_scores)
%#codegen


[val,indx] = sort(predict_scores, 'descend');
scores = val(1:5)*100;
S = coder.load('ClassNames.mat');
labels=S.ClassNames;

%output_label= [labels{indx(1)},' ',sprintf('%2.2f',scores(1)),'%'];
outImg = zeros(227,400,3, 'uint8');
for k = 1:3
    outImg(:,174:end,k) = im(:,:,k);
end
scol = 1;
srow = 1;
outImg = insertText(outImg, [scol, srow], 'Classification with Squeezenet');
srow = srow + 30;
for k = 1:5
    outImg = insertText(outImg, [scol, srow], [labels{indx(k)},' ',sprintf('%2.2f',scores(k)),'%']);
    srow = srow + 25;
end