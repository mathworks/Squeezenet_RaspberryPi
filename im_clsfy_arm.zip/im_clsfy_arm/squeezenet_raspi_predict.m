%Copyright 2020 - 2020 The MathWorks, Inc.

function outImg = squeezenet_raspi_predict()
%#codegen

% A persistent object mynet is used to load the DAGNetwork object.
% At the first call to this function, the persistent object is constructed and
% set up. When the function is called subsequent times, the same object is reused 
% to call predict on inputs, avoiding reconstructing and reloading the
% network object.

r = raspi('ramsraspberrypi','pi','raspberry'); 
w=webcam(r);


persistent net;
opencv_linkflags = '`pkg-config --cflags --libs opencv`';
coder.updateBuildInfo('addLinkFlags',opencv_linkflags);
if isempty(net)
    net = coder.loadDeepLearningNetwork('squeezenet', 'squeezenet');
end


I=snapshot(w);
in = imresize(I,[227,227]);

predict_scores = net.predict(in);

% Annotate detections in the image.
outImg = postprocess(in,predict_scores);
displayImage(r,outImg);
